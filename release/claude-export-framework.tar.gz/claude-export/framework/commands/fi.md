Запусти протокол завершения спринта.

1. `npm run build` (если есть)
2. `npm run dialog:export` — экспорт диалогов
3. Обновить документацию
4. `git add -A && git commit`
5. Спросить: "Сделать git push?"
