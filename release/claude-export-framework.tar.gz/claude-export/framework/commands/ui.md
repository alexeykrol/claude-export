Запусти Web UI для просмотра диалогов.

```bash
npm run dialog:ui
```

Откроется http://localhost:3333
